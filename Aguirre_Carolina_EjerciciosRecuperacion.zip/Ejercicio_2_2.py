import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re
from scipy.stats import pearsonr as correlation 

df = pd.read_csv('automobiles.csv')

def uniques(col:pd.Series):
    
    l = list(col.unique())
    l = ';'.join(l).split(';')
    return list(set(l))

def filter_not_nulls(df, *cols):
   
 
    f = df[cols[0]].notnull()
 
    for col in cols[1:]:
        f = f & df[col].notnull()
    return df[f]

#*****************************************************************************

new_df = filter_not_nulls(df, 'horsepower', 'average-mileage')
x = new_df['horsepower'].to_numpy()
y = new_df['average-mileage'].to_numpy()
corr = np.corrcoef(x=x, y=y)
print(corr)
plt.figure(figsize=(9,9), facecolor='w')
plt.scatter(x=x, y=y)
plt.title('horsepower y average-mileage')
plt.xlabel('horsepower')
plt.ylabel('average-mileage')

#***********************************************************************************

uniques = df['body-style'].unique()

for unique in uniques:
  new_df = df[df['body-style']== unique]
  x = new_df['horsepower'].to_numpy() 
  y = new_df['average-mileage'].to_numpy()
  corr = np.corrcoef(x=x, y=y)
  print(corr)
  plt.figure(figsize=(9,9), facecolor='w')
  plt.scatter(x=x, y=y)
  plt.title('horsepower y average-mileage')
  plt.xlabel('horsepower')
  plt.ylabel('average-mileage')