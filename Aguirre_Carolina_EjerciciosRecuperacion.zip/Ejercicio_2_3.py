import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re

df = pd.read_csv('automobiles.csv')

def sub_str(str_, sub_str_):
  
    sub_str_ = sub_str_.replace(r'++', r'\+\+')
    reg = re.compile('(;|^)' + sub_str_ + '(;|$)')
 
    return bool(reg.findall(str_))
 
def uniques(col:pd.Series):
    
    l = list(col.unique())
    l = ';'.join(l).split(';')
    return list(set(l))

def filter_not_nulls(df, *cols):
   
 
    f = df[cols[0]].notnull()
 
    for col in cols[1:]:
        f = f & df[col].notnull()
    return df[f]

def five_numbers_summary(col):

    mini = col.min()  
    maxi = col.max()
    ql1   = col.quantile(0.25)
    ql2   = col.quantile(0.5)
    ql3   = col.quantile(0.75)
    return mini, maxi, ql1, ql2, ql3

def std_mean(col):

    return col.std(), col.mean()

new_df = filter_not_nulls(df, 'body-style', 'horsepower', 'average-mileage', 'price') 
b = ['horsepower', 'average-mileage', 'price']
uniques_ = uniques(new_df['body-style'])  
d_category = {}
                                           
for uni in uniques_:
 
    filter_df = new_df['body-style'].apply(sub_str, args=(uni,))
    
    f_df = new_df[filter_df]
 
    d_category[uni] = f_df


sumary = 'Min = {0}, Max = {1}, Q1 = {2}, Median = {3}, Q3 = {4} '
i = 1
plt.figure(figsize=(16,26), facecolor='w')
for elemento in range(0,len(b)):
  for category, g_df in d_category.items():
    print(category, sumary.format(*five_numbers_summary(g_df[b[elemento]])))
    plt.subplot(4,4,i)
    plt.boxplot(g_df[b[elemento]], sym='')
    plt.xlabel(category[:10])
    plt.ylabel(b[elemento])
    plt.tight_layout()
    i += 1